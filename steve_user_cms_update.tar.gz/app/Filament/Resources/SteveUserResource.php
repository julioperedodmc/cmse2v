<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SteveUserResource\Pages;
use App\Models\Steve\WebUser;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class SteveUserResource extends Resource
{
    protected static ?string $model = WebUser::class;

    protected static ?string $navigationIcon = 'heroicon-o-key';

    protected static ?string $navigationGroup = 'Configuración';

    protected static ?string $navigationLabel = 'Usuarios SteVe (OCPP)';

    protected static ?string $modelLabel = 'Usuario SteVe';

    protected static ?string $pluralModelLabel = 'Usuarios SteVe (OCPP)';

    protected static ?int $navigationSort = 105;

    public static function canViewAny(): bool
    {
        return auth()->user()?->hasRole('super_admin') ?? false;
    }

    public static function canCreate(): bool
    {
        return auth()->user()?->hasRole('super_admin') ?? false;
    }

    public static function canEdit(Model $record): bool
    {
        return auth()->user()?->hasRole('super_admin') ?? false;
    }

    public static function canDelete(Model $record): bool
    {
        // Solo permitir borrar usuarios creados manualmente con ID > 2
        // para proteger a los usuarios críticos (e2vadm y mgr_api)
        return (auth()->user()?->hasRole('super_admin') ?? false) && ((int) $record->web_user_pk > 2);
    }

    public static function canDeleteAny(): bool
    {
        return false;
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Datos del Usuario SteVe')
                    ->description('Credenciales de acceso para el panel administrativo o APIs del servidor OCPP SteVe (Puerto 8081/8180).')
                    ->schema([
                        Forms\Components\TextInput::make('username')
                            ->label('Nombre de Usuario')
                            ->required()
                            ->maxLength(100)
                            ->unique(ignoreRecord: true)
                            ->helperText('Nombre de usuario único para identificarse en SteVe.'),

                        Forms\Components\TextInput::make('password')
                            ->label('Contraseña')
                            ->password()
                            ->revealable()
                            ->required(fn(string $operation): bool => $operation === 'create')
                            ->minLength(8)
                            ->same('password_confirmation')
                            ->dehydrated(fn($state) => filled($state))
                            ->dehydrateStateUsing(fn($state) => password_hash($state, PASSWORD_BCRYPT))
                            ->helperText(fn(string $operation): string => $operation === 'create'
                                ? 'Mínimo 8 caracteres. Se cifrará con BCrypt de forma segura.'
                                : 'Dejar en blanco si no desea modificar la contraseña actual.'),

                        Forms\Components\TextInput::make('password_confirmation')
                            ->label('Confirmar Contraseña')
                            ->password()
                            ->revealable()
                            ->required(fn(string $operation): bool => $operation === 'create')
                            ->dehydrated(false)
                            ->helperText('Vuelva a escribir la contraseña para confirmar.'),
                    ])
                    ->columns(1),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('web_user_pk')
                    ->label('ID')
                    ->sortable()
                    ->badge()
                    ->color('gray'),

                Tables\Columns\TextColumn::make('username')
                    ->label('Nombre de Usuario')
                    ->searchable()
                    ->sortable()
                    ->weight('bold')
                    ->icon('heroicon-o-user'),

                Tables\Columns\TextColumn::make('role_description')
                    ->label('Función / Rol')
                    ->badge()
                    ->color(fn(WebUser $record): string => match ((int) $record->web_user_pk) {
                        1 => 'success',
                        2 => 'info',
                        default => 'warning',
                    }),

                Tables\Columns\TextColumn::make('status')
                    ->label('Estado')
                    ->badge()
                    ->color('success')
                    ->default('Habilitado'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\Action::make('change_password')
                    ->label('Cambiar Contraseña')
                    ->icon('heroicon-o-key')
                    ->color('warning')
                    ->button()
                    ->modalHeading(fn(WebUser $record) => "Cambiar Contraseña de SteVe: {$record->username}")
                    ->modalDescription('Ingrese una nueva contraseña para acceder al panel o API de SteVe. Se cifrará con BCrypt y tendrá efecto inmediato.')
                    ->modalIcon('heroicon-o-lock-closed')
                    ->modalSubmitActionLabel('Actualizar Contraseña')
                    ->form([
                        Forms\Components\TextInput::make('new_password')
                            ->label('Nueva Contraseña')
                            ->password()
                            ->revealable()
                            ->required()
                            ->minLength(8)
                            ->same('new_password_confirmation')
                            ->helperText('Mínimo 8 caracteres.'),

                        Forms\Components\TextInput::make('new_password_confirmation')
                            ->label('Confirmar Nueva Contraseña')
                            ->password()
                            ->revealable()
                            ->required()
                            ->helperText('Vuelva a escribir la contraseña para confirmar que coincida.'),
                    ])
                    ->action(function (WebUser $record, array $data): void {
                        $hash = password_hash($data['new_password'], PASSWORD_BCRYPT);
                        $record->password = $hash;
                        $record->save();

                        // Auditoría en log del sistema
                        $adminEmail = auth()->user()?->email ?? 'desconocido';
                        Log::info("AUDITORIA_SEGURIDAD: El administrador [{$adminEmail}] actualizó la contraseña del usuario SteVe ID {$record->web_user_pk} ({$record->username}).");

                        if (function_exists('activity')) {
                            try {
                                activity('steve_security')
                                    ->causedBy(auth()->user())
                                    ->performedOn($record)
                                    ->log("Cambio de contraseña para usuario SteVe '{$record->username}'");
                            } catch (\Throwable $t) {
                                // Fallback seguro si la tabla de actividades no está migrada
                            }
                        }

                        Notification::make()
                            ->title('Contraseña actualizada con éxito')
                            ->body("La nueva contraseña para '{$record->username}' ya está activa en el servidor SteVe.")
                            ->success()
                            ->send();
                    }),

                Tables\Actions\EditAction::make()
                    ->label('Editar')
                    ->modalHeading(fn(WebUser $record) => "Editar Usuario SteVe: {$record->username}")
                    ->mutateRecordDataUsing(function (array $data): array {
                        $data['password'] = null;
                        return $data;
                    })
                    ->using(function (Model $record, array $data): Model {
                        if (!empty($data['password'])) {
                            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
                        } else {
                            unset($data['password']);
                        }
                        $record->update($data);
                        return $record;
                    }),

                Tables\Actions\DeleteAction::make()
                    ->label('Eliminar')
                    ->modalHeading(fn(WebUser $record) => "Eliminar Usuario SteVe: {$record->username}")
                    ->modalDescription('¿Está seguro de que desea eliminar este usuario adicional de SteVe?')
                    ->visible(fn(WebUser $record): bool => (int) $record->web_user_pk > 2),
            ])
            ->bulkActions([
                // No permitir eliminación masiva para proteger cuentas de SteVe
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ManageSteveUsers::route('/'),
        ];
    }
}
