<?php

namespace App\Models\Steve;

use Illuminate\Database\Eloquent\Model;

class WebUser extends Model
{
    protected $connection = 'steve';
    protected $table = 'web_user';
    protected $primaryKey = 'web_user_pk';
    public $timestamps = false;

    protected $fillable = [
        'username',
        'password',
    ];

    protected $hidden = [
        'password',
    ];

    /**
     * Get a human-readable description of the user's role in SteVe.
     */
    public function getRoleDescriptionAttribute(): string
    {
        return match ((int) $this->web_user_pk) {
            1 => 'Administrador Web SteVe (Principal)',
            2 => 'Usuario API / Integración',
            default => 'Operador SteVe',
        };
    }
}
